import { AlertTriangle } from "lucide-react"
import { C } from "@/lib/design-tokens"
import { RISK_SIGNAL_LABELS, STUDENTS } from "@/lib/mock-data"
import type { Student } from "@/lib/types"

interface RiskSignalsPanelProps {
  onSelect: (student: Student) => void
}

export function RiskSignalsPanel({ onSelect }: RiskSignalsPanelProps) {
  const flagged = STUDENTS.filter((s) => s.riskSignals.length > 0)

  return (
    <div className="rounded-2xl border bg-white p-5" style={{ borderColor: C.border }}>
      <p
        className="sq-body flex items-center gap-1.5 text-sm font-semibold"
        style={{ color: C.text }}
      >
        <AlertTriangle size={15} />
        Observable risk signals
      </p>
      <p className="sq-body mt-1 text-xs" style={{ color: C.muted }}>
        Structural anomalies for human review — never a claim of cheating.
      </p>
      <div className="mt-3 space-y-2">
        {flagged.map((s) =>
          s.riskSignals.map((rs) => (
            <button
              key={String(s.id) + rs}
              onClick={() => onSelect(s)}
              className="sq-row flex w-full items-center justify-between rounded-xl border px-3 py-2.5 text-left"
              style={{ borderColor: C.border }}
            >
              <div>
                <p className="sq-body text-xs font-semibold" style={{ color: C.text }}>
                  {s.name}
                </p>
                <p className="sq-body text-xs" style={{ color: C.muted }}>
                  {RISK_SIGNAL_LABELS[rs]}
                </p>
              </div>
              <span
                className="sq-body rounded-full px-2.5 py-1 text-xs font-semibold"
                style={{ backgroundColor: C.amberWash, color: C.oliveEarth }}
              >
                Review needed
              </span>
            </button>
          )),
        )}
      </div>
    </div>
  )
}
