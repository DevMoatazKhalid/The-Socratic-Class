"use client"

import { AlertTriangle, X } from "lucide-react"
import { ChatBubble } from "@/components/ui/chat-bubble"
import { OutcomePill } from "@/components/ui/outcome-pill"
import { C } from "@/lib/design-tokens"
import { RISK_SIGNAL_LABELS } from "@/lib/mock-data"
import type { Student } from "@/lib/types"

interface ProvenanceModalProps {
  student: Student
  onClose: () => void
}

export function ProvenanceModal({ student, onClose }: ProvenanceModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(45,41,38,0.55)" }}
      role="dialog"
      aria-modal="true"
      aria-label={`Socratic provenance for ${student.name}`}
    >
      <div
        className="w-full rounded-3xl bg-white p-6 md:p-8"
        style={{ maxWidth: "680px", maxHeight: "88vh", overflowY: "auto" }}
      >
        <div className="flex items-start justify-between">
          <div>
            <p
              className="sq-body text-xs font-semibold uppercase tracking-wide"
              style={{ color: C.muted }}
            >
              Socratic Provenance
            </p>
            <h2 className="sq-display mt-1 text-lg font-semibold" style={{ color: C.text }}>
              {student.name}
            </h2>
            <p className="sq-body text-xs" style={{ color: C.muted }}>
              {student.email}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close provenance"
            className="rounded-full p-1.5"
            style={{ backgroundColor: C.peachWash }}
          >
            <X size={16} style={{ color: C.oliveEarth }} />
          </button>
        </div>

        {student.riskSignals.length > 0 && (
          <div className="mt-4 rounded-2xl p-4" style={{ backgroundColor: C.amberWash }}>
            <p
              className="sq-body flex items-center gap-1.5 text-xs font-semibold"
              style={{ color: C.oliveEarth }}
            >
              <AlertTriangle size={13} />
              {student.riskSignals.length} observable signal
              {student.riskSignals.length > 1 ? "s" : ""} — review needed, not an accusation
            </p>
            <ul className="mt-2 space-y-1">
              {student.riskSignals.map((rs) => (
                <li key={rs} className="sq-body text-xs" style={{ color: C.oliveEarth }}>
                  · {RISK_SIGNAL_LABELS[rs]}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-6">
          <p className="sq-body mb-2 text-sm font-semibold" style={{ color: C.text }}>
            1. Initial attempt
          </p>
          <pre
            className="sq-body overflow-x-auto rounded-2xl border p-4 text-xs"
            style={{
              borderColor: C.border,
              backgroundColor: C.bgOff,
              color: C.text,
              fontFamily: "monospace",
            }}
          >
            {student.trace.initialAttempt || "(no attempt yet)"}
          </pre>
        </div>

        <div className="mt-6">
          <p className="sq-body mb-2 text-sm font-semibold" style={{ color: C.text }}>
            2. Socratic interventions
          </p>
          <div className="space-y-2">
            {student.trace.interventions.length === 0 && (
              <p className="sq-body text-xs" style={{ color: C.muted }}>
                No coaching turns yet.
              </p>
            )}
            {student.trace.interventions.map((m, i) => (
              <ChatBubble key={i} role={m.role === "student" ? "user" : "assistant"} content={m.content} />
            ))}
          </div>
        </div>

        <div className="mt-6">
          <p className="sq-body mb-2 text-sm font-semibold" style={{ color: C.text }}>
            3. Code revisions
          </p>
          <div className="space-y-2">
            {student.trace.revisions.length === 0 && (
              <p className="sq-body text-xs" style={{ color: C.muted }}>
                No revisions logged yet.
              </p>
            )}
            {student.trace.revisions.map((r, i) => (
              <div
                key={i}
                className="flex items-center gap-3 rounded-xl border px-3 py-2"
                style={{ borderColor: C.border }}
              >
                <span className="sq-body text-xs font-semibold" style={{ color: C.muted }}>
                  {r.ts}
                </span>
                <span className="sq-body text-xs" style={{ color: C.text }}>
                  {r.summary}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <p className="sq-body mb-2 text-sm font-semibold" style={{ color: C.text }}>
            4. Verification outcome
          </p>
          {student.trace.verificationDetail.length === 0 ? (
            <p className="sq-body text-xs" style={{ color: C.muted }}>
              Not yet completed.
            </p>
          ) : (
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              {student.trace.verificationDetail.map((v, i) => (
                <div key={i} className="rounded-xl border p-3" style={{ borderColor: C.border }}>
                  <div className="flex items-center justify-between">
                    <span className="sq-body text-xs font-semibold" style={{ color: C.text }}>
                      {v.q}
                    </span>
                    <OutcomePill outcome={v.outcome} />
                  </div>
                  <p className="sq-body mt-1 text-xs" style={{ color: C.muted }}>
                    {v.tag}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
