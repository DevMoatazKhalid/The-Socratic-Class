import type { LucideIcon } from "lucide-react"
import { C } from "@/lib/design-tokens"

interface MetricTint {
  soft: string
  fg: string
}

interface MetricCardProps {
  icon: LucideIcon
  label: string
  value: string | number
  tint: MetricTint
}

export function MetricCard({ icon: Icon, label, value, tint }: MetricCardProps) {
  return (
    <div className="rounded-2xl border bg-white p-5" style={{ borderColor: C.border }}>
      <div
        className="flex h-9 w-9 items-center justify-center rounded-full"
        style={{ backgroundColor: tint.soft }}
      >
        <Icon size={16} style={{ color: tint.fg }} />
      </div>
      <p className="sq-display mt-3 text-2xl font-semibold" style={{ color: C.text }}>
        {value}
      </p>
      <p className="sq-body text-xs font-medium" style={{ color: C.muted }}>
        {label}
      </p>
    </div>
  )
}
