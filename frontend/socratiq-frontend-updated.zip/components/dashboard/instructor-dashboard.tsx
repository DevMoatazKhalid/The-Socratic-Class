"use client"

import { useMemo, useState } from "react"
import { AlertTriangle, BadgeCheck, Gauge, GraduationCap, Users } from "lucide-react"
import { AppTopBar } from "@/components/app-top-bar"
import { MetricCard } from "./metric-card"
import { MisconceptionsPanel } from "./misconceptions-panel"
import { RiskSignalsPanel } from "./risk-signals-panel"
import { StudentsTable } from "./students-table"
import { ProvenanceModal } from "./provenance-modal"
import { C } from "@/lib/design-tokens"
import { ASSIGNMENT, STUDENTS } from "@/lib/mock-data"
import { useSession } from "@/context/session-context"
import type { Mastery, Student, VerificationDetailItem } from "@/lib/types"

export function InstructorDashboard() {
  const { teacherName, studentName, liveState } = useSession()
  const [selected, setSelected] = useState<Student | null>(null)

  const liveStudent = useMemo<Student | null>(() => {
    const hasLiveActivity =
      liveState.attempt.trim().length > 0 || liveState.messages.length > 0
    if (!hasLiveActivity) return null

    const mastery: Mastery =
      liveState.verificationOverall === "PASS"
        ? "Strong"
        : liveState.verificationOverall === "PARTIAL"
          ? "Moderate"
          : "—"

    // Flatten the live verification results into the trace's display shape.
    const verificationDetail: VerificationDetailItem[] = (liveState.verificationDetail || []).map(
      (r) => ({ q: r.q.type, outcome: r.outcome, tag: r.tag }),
    )

    return {
      id: "live",
      name: `${studentName || "Demo Student"} (live)`,
      email: "live-session@socratiq.app",
      taskSubmission: liveState.submitted ? 100 : 0,
      socraticUsage: Math.min(
        100,
        liveState.messages.filter((m) => m.role === "assistant").length * 14,
      ),
      externalUsage: 0,
      mastery,
      verification: liveState.verificationOverall || "IN_PROGRESS",
      riskSignals: [],
      trace: {
        initialAttempt: liveState.attempt,
        interventions: liveState.messages.map((m) => ({
          role: m.role === "user" ? "student" : "coach",
          content: m.content,
        })),
        revisions: liveState.revisions,
        verificationDetail,
      },
    }
  }, [liveState, studentName])

  const rows = liveStudent ? [liveStudent, ...STUDENTS] : STUDENTS
  const flaggedCount = STUDENTS.reduce((n, s) => n + s.riskSignals.length, 0)
  const passCount = rows.filter((s) => s.verification === "PASS").length
  const passRate = Math.round((passCount / rows.length) * 100)

  return (
    <div className="min-h-screen w-full" style={{ backgroundColor: C.bgOff }}>
      <AppTopBar
        name={teacherName}
        fallback="Teacher"
        icon={GraduationCap}
        iconBg={C.amberWash}
        iconFg={C.oliveEarth}
      />

      <main className="mx-auto max-w-6xl px-6 py-8 md:px-10">
        <p
          className="sq-body text-xs font-semibold uppercase tracking-wide"
          style={{ color: C.muted }}
        >
          {ASSIGNMENT.course}
        </p>
        <h1 className="sq-display mt-1 text-2xl font-semibold" style={{ color: C.text }}>
          Learning Intelligence
        </h1>

        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          <MetricCard
            icon={Users}
            label="Active students"
            value={rows.length}
            tint={{ soft: C.sageWash, fg: C.oliveEarth }}
          />
          <MetricCard
            icon={Gauge}
            label="Average learning index"
            value="72%"
            tint={{ soft: C.peachWash, fg: C.terracotta }}
          />
          <MetricCard
            icon={BadgeCheck}
            label="Verification pass rate"
            value={`${passRate}%`}
            tint={{ soft: C.sageWash, fg: C.oliveEarth }}
          />
          <MetricCard
            icon={AlertTriangle}
            label="Detected risk signals"
            value={flaggedCount}
            tint={{ soft: C.amberWash, fg: C.amber }}
          />
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
          <MisconceptionsPanel />
          <RiskSignalsPanel onSelect={setSelected} />
        </div>

        <StudentsTable rows={rows} onSelect={setSelected} />
      </main>

      {selected && <ProvenanceModal student={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}
