import { ChevronRight } from "lucide-react"
import { OutcomePill } from "@/components/ui/outcome-pill"
import { C } from "@/lib/design-tokens"
import type { Student } from "@/lib/types"

interface StudentsTableProps {
  rows: Student[]
  onSelect: (student: Student) => void
}

const HEADERS = [
  "Student",
  "Task submission",
  "Socratic AI usage",
  "External AI usage",
  "Verification",
  "",
]

export function StudentsTable({ rows, onSelect }: StudentsTableProps) {
  return (
    <div
      className="mt-6 overflow-hidden rounded-2xl border bg-white"
      style={{ borderColor: C.border }}
    >
      <p className="sq-body px-5 pt-5 text-sm font-semibold" style={{ color: C.text }}>
        Students
      </p>
      <div className="mt-3 overflow-x-auto">
        <table className="sq-body w-full text-left text-sm">
          <thead>
            <tr style={{ borderTop: `1px solid ${C.border}` }}>
              {HEADERS.map((h, i) => (
                <th
                  key={h || `col-${i}`}
                  className="px-5 py-3 text-xs font-semibold"
                  style={{ color: C.muted }}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <tr
                key={s.id}
                className="sq-row"
                style={{
                  borderTop: `1px solid ${C.border}`,
                  backgroundColor: s.id === "live" ? C.peachRow : "transparent",
                }}
              >
                <td className="px-5 py-3 font-semibold" style={{ color: C.text }}>
                  <span className="flex items-center gap-2">
                    {s.id === "live" && (
                      <span
                        className="sq-body rounded-full px-2 py-0.5 text-xs font-bold text-white"
                        style={{ backgroundColor: C.terracotta }}
                      >
                        LIVE
                      </span>
                    )}
                    {s.name}
                  </span>
                </td>
                <td className="px-5 py-3" style={{ color: C.text }}>
                  {s.taskSubmission}%
                </td>
                <td className="px-5 py-3" style={{ color: C.text }}>
                  {s.socraticUsage}%
                </td>
                <td className="px-5 py-3" style={{ color: C.text }}>
                  {s.externalUsage}%
                </td>
                <td className="px-5 py-3">
                  <OutcomePill outcome={s.verification} />
                </td>
                <td className="px-5 py-3 text-right">
                  <button
                    onClick={() => onSelect(s)}
                    className="sq-body inline-flex items-center gap-1 text-xs font-semibold"
                    style={{ color: C.oliveEarth }}
                  >
                    View trace
                    <ChevronRight size={13} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
