import { ClipboardList } from "lucide-react"
import { C } from "@/lib/design-tokens"
import { MISCONCEPTIONS } from "@/lib/mock-data"

export function MisconceptionsPanel() {
  const maxCount = Math.max(...MISCONCEPTIONS.map((m) => m.count))

  return (
    <div className="rounded-2xl border bg-white p-5" style={{ borderColor: C.border }}>
      <p
        className="sq-body flex items-center gap-1.5 text-sm font-semibold"
        style={{ color: C.text }}
      >
        <ClipboardList size={15} />
        Common misconceptions
      </p>
      <div className="mt-4 space-y-3">
        {MISCONCEPTIONS.map((m) => (
          <div key={m.label}>
            <div className="mb-1 flex items-center justify-between">
              <span className="sq-body text-xs" style={{ color: C.text }}>
                {m.label}
              </span>
              <span className="sq-body text-xs font-semibold" style={{ color: C.muted }}>
                {m.count}
              </span>
            </div>
            <div className="h-1.5 w-full rounded-full" style={{ backgroundColor: C.peachWash }}>
              <div
                className="h-1.5 rounded-full"
                style={{
                  width: `${(m.count / maxCount) * 100}%`,
                  background: `linear-gradient(90deg, ${C.amber}, ${C.terracotta})`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
