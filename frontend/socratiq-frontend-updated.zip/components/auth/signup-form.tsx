"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Logo } from "@/components/ui/logo"
import { PrimaryButton } from "@/components/ui/primary-button"
import { BackLink } from "@/components/ui/back-link"
import { FormField } from "@/components/ui/form-field"
import { C } from "@/lib/design-tokens"
import { useSession } from "@/context/session-context"
import type { Role } from "@/lib/types"

interface SignupFormState {
  name: string
  email: string
  password: string
  confirm: string
}

export function SignupForm({ role }: { role: Role }) {
  const router = useRouter()
  const { setStudentName, setTeacherName } = useSession()
  const isStudent = role === "student"
  const [form, setForm] = useState<SignupFormState>({
    name: "",
    email: "",
    password: "",
    confirm: "",
  })

  const update =
    (key: keyof SignupFormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }))

  // Deliberately no <form>/onSubmit — native form submission does not reliably
  // fire inside sandboxed preview iframes, so we drive completion explicitly.
  const submit = () => {
    const fullName = form.name.trim() || (isStudent ? "Student" : "Teacher")
    const first = fullName.split(" ")[0]
    if (isStudent) {
      setStudentName(first)
      router.push("/workspace")
    } else {
      setTeacherName(first)
      router.push("/dashboard")
    }
  }

  return (
    <div
      className="flex min-h-screen flex-col items-center justify-center px-6 py-16"
      style={{ backgroundColor: C.bg }}
    >
      <Logo />
      <div
        className="mt-10 w-full max-w-sm rounded-3xl border px-8 py-10 text-center shadow-sm"
        style={{ backgroundColor: "#FFFFFF", borderColor: C.border }}
      >
        <h2 className="sq-display text-xl font-semibold" style={{ color: C.text }}>
          Sign up as {isStudent ? "student" : "teacher"}
        </h2>
        <div className="mt-8">
          <FormField
            placeholder={`Enter ${role} name...`}
            value={form.name}
            onChange={update("name")}
          />
          <FormField
            placeholder={`Enter ${role} email...`}
            value={form.email}
            onChange={update("email")}
          />
          <FormField
            type="password"
            placeholder={`Enter ${role} password...`}
            value={form.password}
            onChange={update("password")}
          />
          <FormField
            type="password"
            placeholder="Confirm password..."
            value={form.confirm}
            onChange={update("confirm")}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit()
            }}
          />
          <PrimaryButton
            onClick={submit}
            tone={isStudent ? "primary" : "amber"}
            className="mt-2 w-full"
          >
            Next
          </PrimaryButton>
        </div>
      </div>
      <BackLink onClick={() => router.push("/signup")} />
    </div>
  )
}
