"use client"

import { useRouter } from "next/navigation"
import { Logo } from "@/components/ui/logo"
import { PrimaryButton } from "@/components/ui/primary-button"
import { BackLink } from "@/components/ui/back-link"
import { C } from "@/lib/design-tokens"
import { useSession } from "@/context/session-context"
import type { Role } from "@/lib/types"

type AuthTab = "signup" | "login"

const TABS: { key: AuthTab; label: string; href: string }[] = [
  { key: "signup", label: "Sign Up", href: "/signup" },
  { key: "login", label: "Log In", href: "/login" },
]

export function AuthPanel({ tab }: { tab: AuthTab }) {
  const router = useRouter()
  const { setStudentName, setTeacherName } = useSession()

  const demoLogin = (role: Role) => {
    if (role === "student") {
      setStudentName("Demo Student")
      router.push("/workspace")
    } else {
      setTeacherName("Demo Teacher")
      router.push("/dashboard")
    }
  }

  return (
    <div
      className="flex min-h-screen flex-col items-center justify-center px-6 py-16"
      style={{ backgroundColor: C.bg }}
    >
      <Logo />
      <div
        className="mt-10 w-full max-w-sm rounded-3xl border px-8 py-10 text-center shadow-sm"
        style={{ backgroundColor: "#FFFFFF", borderColor: C.border }}
      >
        <div
          className="mx-auto mb-6 flex w-full max-w-xs items-center rounded-full p-1"
          style={{ backgroundColor: C.peachWash }}
        >
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => router.push(t.href)}
              className="sq-body flex-1 rounded-full py-2 text-xs font-semibold"
              style={{
                transition: "background-color 0.15s ease, color 0.15s ease",
                backgroundColor: tab === t.key ? C.amber : "transparent",
                color: tab === t.key ? "#FFFFFF" : C.oliveEarth,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === "signup" ? (
          <>
            <h2 className="sq-display text-xl font-semibold" style={{ color: C.text }}>
              Choose what to sign up as
            </h2>
            <div className="mt-8 flex flex-col gap-4">
              <PrimaryButton tone="primary" onClick={() => router.push("/signup/student")}>
                Sign up as student
              </PrimaryButton>
              <PrimaryButton tone="amber" onClick={() => router.push("/signup/teacher")}>
                Sign up as teacher
              </PrimaryButton>
            </div>
          </>
        ) : (
          <>
            <h2 className="sq-display text-xl font-semibold" style={{ color: C.text }}>
              Log in
            </h2>
            <p className="sq-body mt-2 text-xs" style={{ color: C.muted }}>
              Demo credentials are pre-filled — pick a role to jump straight into a live session.
            </p>
            <div className="mt-6 flex flex-col gap-4">
              <PrimaryButton tone="primary" onClick={() => demoLogin("student")}>
                Log in as demo student
              </PrimaryButton>
              <PrimaryButton tone="amber" onClick={() => demoLogin("teacher")}>
                Log in as demo teacher
              </PrimaryButton>
            </div>
          </>
        )}
      </div>
      <BackLink onClick={() => router.push("/")} />
    </div>
  )
}
