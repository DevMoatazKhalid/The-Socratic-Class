"use client"

import { useRouter } from "next/navigation"
import { SiteHeader } from "./site-header"
import { HeroSection } from "./hero-section"
import { AboutSection } from "./about-section"
import { SiteFooter } from "./site-footer"

export function LandingPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen w-full bg-white">
      <SiteHeader onLogin={() => router.push("/login")} onSignup={() => router.push("/signup")} />
      <HeroSection onSignup={() => router.push("/signup")} />
      <AboutSection />
      <SiteFooter />
    </div>
  )
}
