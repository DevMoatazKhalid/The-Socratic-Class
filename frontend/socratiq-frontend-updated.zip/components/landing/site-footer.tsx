import { C } from "@/lib/design-tokens"

export function SiteFooter() {
  return (
    <footer
      className="flex flex-col-reverse items-center justify-between gap-2 px-8 py-10 text-center md:flex-row md:text-left md:px-16"
      style={{ backgroundColor: C.oliveDark }}
    >
      <p className="sq-body text-xs" style={{ color: C.peach }}>
        © SocratiQ · Copyrights reserved
      </p>
      <p className="text-sm font-medium text-white" style={{ fontFamily: "var(--font-mono, monospace)" }}>
        socratic@gmail.com
      </p>
    </footer>
  )
}
