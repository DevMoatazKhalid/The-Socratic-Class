import { C } from "@/lib/design-tokens"

export function AboutSection() {
  return (
    <section className="mx-auto max-w-2xl px-8 py-16 text-left md:px-16">
      <hr className="mb-10 w-16" style={{ borderColor: C.sage }} />
      <h2 className="sq-display text-2xl font-semibold" style={{ color: C.text }}>
        About
      </h2>
      <p className="sq-body mt-4 text-sm leading-relaxed" style={{ color: C.muted }}>
        <strong style={{ color: C.text }}>SocratiQ</strong> is an interface meant to redefine the use
        of AI in academics, by introducing answers in a way that utilizes the user&apos;s cognitive
        abilities instead of just getting the answers straight away — making AI a tool that truly
        helps the user improve their academic skills and critical thinking capabilities.
      </p>
    </section>
  )
}
