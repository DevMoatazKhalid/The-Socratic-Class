import { Logo } from "@/components/ui/logo"
import { C } from "@/lib/design-tokens"

interface SiteHeaderProps {
  onLogin: () => void
  onSignup: () => void
}

export function SiteHeader({ onLogin, onSignup }: SiteHeaderProps) {
  return (
    <header className="flex items-center justify-between px-8 py-5 md:px-16">
      <Logo />
      <nav className="sq-body flex items-center gap-6 text-sm font-semibold">
        <button onClick={onLogin} style={{ color: C.text }}>
          Log in
        </button>
        <button onClick={onSignup} className="sq-btn sq-primary rounded-full px-5 py-2.5">
          Sign Up
        </button>
      </nav>
    </header>
  )
}
