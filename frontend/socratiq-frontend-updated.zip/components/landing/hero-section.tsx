import { Fragment } from "react"
import { ArrowRight } from "lucide-react"
import { PrimaryButton } from "@/components/ui/primary-button"
import { C } from "@/lib/design-tokens"
import { LOOP_STEPS } from "@/lib/mock-data"

const SPEC_ITEMS = [
  {
    num: "01",
    title: "Socratic, not silent",
    desc: "AI that answers with a question, guiding students to reason it out themselves.",
  },
  {
    num: "02",
    title: "Built for both sides",
    desc: "One workspace for students to learn and teachers to see how they got there.",
  },
  {
    num: "03",
    title: "Skill over shortcuts",
    desc: "Every interaction is designed to build critical thinking, not bypass it.",
  },
]

export function HeroSection({ onSignup }: { onSignup: () => void }) {
  return (
    <>
      <main
        className="px-8 pb-16 pt-16 md:px-16"
        style={{
          backgroundColor: C.bgOff,
          backgroundImage: [
            `radial-gradient(120% 90% at 15% 0%, ${C.peach} 0%, rgba(196,215,242,0) 55%)`,
            `radial-gradient(90% 80% at 90% 10%, ${C.amber} 0%, rgba(175,222,220,0) 60%)`,
            `radial-gradient(70% 60% at 60% 100%, ${C.sage} 0%, rgba(145,168,164,0) 65%)`,
            `linear-gradient(rgba(119,104,113,0.08) 1px, transparent 1px)`,
            `linear-gradient(90deg, rgba(119,104,113,0.08) 1px, transparent 1px)`,
          ].join(", "),
          backgroundSize: "100% 100%, 100% 100%, 100% 100%, 32px 32px, 32px 32px",
        }}
      >
        <div className="mx-auto max-w-2xl text-left">
          <p
            className="mb-3 flex items-center gap-2 text-[11px] tracking-wide"
            style={{ fontFamily: "var(--font-mono, monospace)", color: C.sage }}
          >
            <span style={{ color: C.terracotta }}>N.01</span> CRITICAL THINKING ENGINE
          </p>
          <h1 className="sq-display max-w-xl text-4xl font-semibold leading-tight md:text-5xl" style={{ color: C.text }}>
            A reimagination of generative AI tools into a{" "}
            <span style={{ color: C.terracotta }}>Critical Thinking Engine.</span>
          </h1>
          <p className="sq-body mt-5 max-w-md text-base" style={{ color: C.muted }}>
            A tool for <strong style={{ color: C.text }}>Teachers</strong> and{" "}
            <strong style={{ color: C.text }}>Students</strong>.
          </p>

          <div className="mt-8 flex items-center gap-3">
            <PrimaryButton tone="primary" onClick={onSignup}>
              Sign up now
            </PrimaryButton>
          </div>

          <div className="mt-16 flex flex-wrap items-center gap-2 md:gap-3">
            {LOOP_STEPS.map((step, i) => (
              <Fragment key={step.label}>
                <div
                  className="sq-body flex items-center gap-2 rounded-full border bg-white px-4 py-2.5 text-sm font-semibold shadow-sm"
                  style={{ borderColor: C.border, color: C.text }}
                >
                  <step.icon size={16} style={{ color: i % 2 === 0 ? C.terracotta : C.amberDeep }} />
                  {step.label}
                </div>
                {i < LOOP_STEPS.length - 1 && (
                  <ArrowRight size={16} style={{ color: C.muted }} className="hidden md:block" />
                )}
              </Fragment>
            ))}
          </div>
          <p className="sq-body mt-3 max-w-md text-xs" style={{ color: C.muted }}>
            Every attempt becomes a diagnosis, a question, and a revision — not an answer.
          </p>
        </div>
      </main>

      <div className="grid grid-cols-1 border-y md:grid-cols-3" style={{ borderColor: C.border }}>
        {SPEC_ITEMS.map((item, i) => (
          <div
            key={item.num}
            className="px-8 py-6 md:px-10"
            style={{ borderLeft: i === 0 ? "none" : `1px solid ${C.border}` }}
          >
            <div
              className="mb-2 text-xs"
              style={{ fontFamily: "var(--font-mono, monospace)", color: C.amberDeep }}
            >
              {item.num}
            </div>
            <div className="sq-body text-sm font-bold" style={{ color: C.terracotta }}>
              {item.title}
            </div>
            <div className="sq-body mt-1.5 text-xs leading-relaxed" style={{ color: C.muted }}>
              {item.desc}
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
