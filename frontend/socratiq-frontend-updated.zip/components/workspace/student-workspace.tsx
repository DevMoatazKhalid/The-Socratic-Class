"use client"

import { useState } from "react"
import { User } from "lucide-react"
import { AppTopBar } from "@/components/app-top-bar"
import { AssignmentPanel } from "./assignment-panel"
import { CoachPanel } from "./coach-panel"
import { VerificationModal } from "./verification-modal"
import { C } from "@/lib/design-tokens"
import { diagnose, socraticRespond, thinkingDelay } from "@/lib/socratic-engine"
import { nowLabel } from "@/lib/utils"
import { useSession } from "@/context/session-context"
import type { Outcome, VerificationResult } from "@/lib/types"

export function StudentWorkspace() {
  const { studentName, liveState, setLiveState } = useSession()
  const { attempt, revisions, messages, submitted, verificationOverall } = liveState

  const [chatInput, setChatInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [turnCount, setTurnCount] = useState(messages.filter((m) => m.role === "user").length)
  const [lastLogged, setLastLogged] = useState(attempt)
  const [showVerification, setShowVerification] = useState(false)

  const setAttempt = (val: string) => setLiveState((s) => ({ ...s, attempt: val }))

  const submitAttempt = async () => {
    if (!attempt.trim()) return
    setLiveState((s) => ({
      ...s,
      submitted: true,
      revisions: [{ ts: nowLabel(), summary: "Initial attempt submitted" }],
    }))
    setLastLogged(attempt)
    setLoading(true)
    await thinkingDelay()
    const reply = diagnose(attempt, 0)
    setLiveState((s) => ({ ...s, messages: [{ role: "assistant", content: reply }] }))
    setLoading(false)
    setTurnCount(1)
  }

  const sendMessage = async () => {
    if (!chatInput.trim() || loading) return
    const content = chatInput.trim()
    setLiveState((s) => ({ ...s, messages: [...s.messages, { role: "user", content }] }))
    setChatInput("")
    if (attempt !== lastLogged) {
      setLiveState((s) => ({
        ...s,
        revisions: [...s.revisions, { ts: nowLabel(), summary: "Code revised while chatting" }],
      }))
      setLastLogged(attempt)
    }
    setLoading(true)
    await thinkingDelay()
    const reply = socraticRespond(content, attempt, turnCount)
    setLiveState((s) => ({ ...s, messages: [...s.messages, { role: "assistant", content: reply }] }))
    setLoading(false)
    setTurnCount((t) => t + 1)
  }

  const finishVerification = (overall: Outcome, detail: VerificationResult[]) => {
    setLiveState((s) => ({ ...s, verificationOverall: overall, verificationDetail: detail }))
    setShowVerification(false)
  }

  return (
    <div
      className="flex min-h-screen w-full flex-col"
      style={{ backgroundColor: C.bgOff }}
    >
      <AppTopBar
        name={studentName}
        fallback="Student"
        icon={User}
        iconBg={C.peachWash}
        iconFg={C.terracotta}
      />

      <div className="grid flex-1 grid-cols-1 gap-6 p-6 md:grid-cols-2 md:p-10">
        <AssignmentPanel
          attempt={attempt}
          onAttemptChange={setAttempt}
          submitted={submitted}
          revisionCount={revisions.length}
          verificationOverall={verificationOverall}
          onSubmit={submitAttempt}
          onVerify={() => setShowVerification(true)}
        />
        <CoachPanel
          messages={messages}
          loading={loading}
          submitted={submitted}
          chatInput={chatInput}
          onChatInputChange={setChatInput}
          onSend={sendMessage}
        />
      </div>

      {showVerification && (
        <VerificationModal
          onClose={() => setShowVerification(false)}
          onFinish={finishVerification}
        />
      )}
    </div>
  )
}
