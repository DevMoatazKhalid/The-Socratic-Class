import { BadgeCheck, CheckCircle2 } from "lucide-react"
import { PrimaryButton } from "@/components/ui/primary-button"
import { PolicyBadge } from "./policy-badge"
import { C } from "@/lib/design-tokens"
import { ASSIGNMENT } from "@/lib/mock-data"
import type { Outcome } from "@/lib/types"

interface AssignmentPanelProps {
  attempt: string
  onAttemptChange: (value: string) => void
  submitted: boolean
  revisionCount: number
  verificationOverall: Outcome | null
  onSubmit: () => void
  onVerify: () => void
}

export function AssignmentPanel({
  attempt,
  onAttemptChange,
  submitted,
  revisionCount,
  verificationOverall,
  onSubmit,
  onVerify,
}: AssignmentPanelProps) {
  return (
    <section
      className="flex flex-col rounded-3xl border bg-white p-6"
      style={{ borderColor: C.border }}
    >
      <p
        className="sq-body text-xs font-semibold uppercase tracking-wide"
        style={{ color: C.muted }}
      >
        {ASSIGNMENT.course}
      </p>
      <h1 className="sq-display mt-1 text-xl font-semibold" style={{ color: C.text }}>
        {ASSIGNMENT.title}
      </h1>
      <p className="sq-body mt-2 text-sm" style={{ color: C.muted }}>
        {ASSIGNMENT.topic}
      </p>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <PolicyBadge />
        {verificationOverall && (
          <span
            className="sq-body inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold"
            style={{
              backgroundColor: verificationOverall === "PASS" ? C.sageWash : C.peachWash,
              color: verificationOverall === "PASS" ? C.oliveEarth : C.terracotta,
            }}
          >
            <BadgeCheck size={13} />
            Verification: {verificationOverall === "PASS" ? "Pass" : "Partial"}
          </span>
        )}
      </div>
      <p className="sq-body mt-4 text-sm leading-relaxed" style={{ color: C.text }}>
        {ASSIGNMENT.description}
      </p>

      <div className="mt-6 flex-1">
        <div className="mb-2 flex items-center justify-between">
          <label className="sq-body text-sm font-semibold" style={{ color: C.text }}>
            Your attempt
          </label>
          {submitted && (
            <span className="sq-body text-xs" style={{ color: C.muted }}>
              {revisionCount} revision{revisionCount === 1 ? "" : "s"} logged
            </span>
          )}
        </div>
        <textarea
          value={attempt}
          onChange={(e) => onAttemptChange(e.target.value)}
          placeholder={"def gradient_descent(x, y, theta, alpha, iterations):\n    ..."}
          className="sq-body h-48 w-full resize-none rounded-2xl border p-4 text-sm outline-none focus:ring-2"
          style={{
            borderColor: C.border,
            color: C.text,
            backgroundColor: C.bgOff,
            fontFamily: "monospace",
          }}
        />
        <p className="sq-body mt-1 text-xs" style={{ color: C.muted }}>
          {submitted
            ? "Keep revising — the Coach sees your latest code on every message."
            : "Submit to unlock the Coach; you can keep editing afterward."}
        </p>
      </div>

      {!submitted ? (
        <PrimaryButton
          tone="primary"
          className="mt-5 w-full"
          onClick={onSubmit}
          disabled={!attempt.trim()}
        >
          Submit &amp; Verify
        </PrimaryButton>
      ) : (
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <div
            className="sq-body flex flex-1 items-center gap-2 rounded-2xl px-4 py-3 text-sm font-medium"
            style={{ backgroundColor: C.sageWash, color: C.oliveEarth }}
          >
            <CheckCircle2 size={16} />
            Attempt submitted
          </div>
          <PrimaryButton tone="olive" onClick={onVerify}>
            Complete &amp; Verify Mastery
          </PrimaryButton>
        </div>
      )}
    </section>
  )
}
