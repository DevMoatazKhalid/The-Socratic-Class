import { ShieldCheck } from "lucide-react"
import { C } from "@/lib/design-tokens"

export function GuardrailStatus() {
  return (
    <div
      className="sq-body flex items-center gap-1.5 text-xs font-medium"
      style={{ color: C.muted }}
    >
      <ShieldCheck size={13} style={{ color: C.oliveEarth }} />
      Course RAG Grounded · Guardrails Active
    </div>
  )
}
