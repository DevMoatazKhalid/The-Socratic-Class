import { Sparkles } from "lucide-react"
import { C } from "@/lib/design-tokens"

export function PolicyBadge() {
  return (
    <div
      className="sq-body inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold"
      style={{ backgroundColor: C.sageWash, color: C.oliveEarth }}
    >
      <Sparkles size={13} />
      Mode: Guided AI
    </div>
  )
}
