"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { PrimaryButton } from "@/components/ui/primary-button"
import { OutcomePill } from "@/components/ui/outcome-pill"
import { C } from "@/lib/design-tokens"
import { VERIFICATION_QUESTIONS } from "@/lib/mock-data"
import { evaluateAnswer } from "@/lib/verification-engine"
import type { Outcome, VerificationQuestionId, VerificationResult } from "@/lib/types"

type AnswerMap = Record<VerificationQuestionId, string>

interface VerificationModalProps {
  onClose: () => void
  onFinish: (overall: Outcome, results: VerificationResult[]) => void
}

export function VerificationModal({ onClose, onFinish }: VerificationModalProps) {
  const [answers, setAnswers] = useState<AnswerMap>({ explain: "", modify: "", transfer: "" })
  const [results, setResults] = useState<VerificationResult[] | null>(null)

  const anyFilled = Object.values(answers).some((v) => v.trim().length > 10)

  const submit = () => {
    const r: VerificationResult[] = VERIFICATION_QUESTIONS.map((q) => ({
      q,
      ...evaluateAnswer(q, answers[q.id]),
    }))
    setResults(r)
  }

  const overall: Outcome | null = results
    ? results.every((r) => r.outcome === "PASS")
      ? "PASS"
      : "PARTIAL"
    : null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(45,41,38,0.55)" }}
      role="dialog"
      aria-modal="true"
      aria-label="Learning verification"
    >
      <div
        className="w-full rounded-3xl bg-white p-6 md:p-8"
        style={{ maxWidth: "640px", maxHeight: "85vh", overflowY: "auto" }}
      >
        <div className="flex items-start justify-between">
          <div>
            <p
              className="sq-body text-xs font-semibold uppercase tracking-wide"
              style={{ color: C.muted }}
            >
              Learning Verification
            </p>
            <h2 className="sq-display mt-1 text-lg font-semibold" style={{ color: C.text }}>
              Explain · Modify · Transfer
            </h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close verification"
            className="rounded-full p-1.5"
            style={{ backgroundColor: C.peachWash }}
          >
            <X size={16} style={{ color: C.oliveEarth }} />
          </button>
        </div>

        {!results ? (
          <div className="mt-6 space-y-5">
            {VERIFICATION_QUESTIONS.map((q) => (
              <div key={q.id}>
                <div className="mb-1.5 flex items-center gap-2">
                  <span
                    className="sq-body rounded-full px-2.5 py-1 text-xs font-semibold"
                    style={{ backgroundColor: C.peachWash, color: C.terracotta }}
                  >
                    {q.type}
                  </span>
                </div>
                <p className="sq-body mb-2 text-sm font-medium" style={{ color: C.text }}>
                  {q.prompt}
                </p>
                <textarea
                  value={answers[q.id]}
                  onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
                  placeholder="Type your response..."
                  className="sq-body h-20 w-full resize-none rounded-2xl border p-3 text-sm outline-none focus:ring-2"
                  style={{ borderColor: C.border, color: C.text }}
                />
              </div>
            ))}
            <PrimaryButton tone="amber" className="w-full" onClick={submit} disabled={!anyFilled}>
              Submit for Review
            </PrimaryButton>
            {!anyFilled && (
              <p className="sq-body text-center text-xs" style={{ color: C.muted }}>
                Write at least one substantive answer (10+ characters) to submit.
              </p>
            )}
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            <div
              className="rounded-2xl p-4"
              style={{ backgroundColor: overall === "PASS" ? C.sageWash : C.peachWash }}
            >
              <p
                className="sq-body text-sm font-semibold"
                style={{ color: overall === "PASS" ? C.oliveEarth : C.terracotta }}
              >
                Overall outcome: {overall === "PASS" ? "Pass" : "Partial"}
              </p>
              <p className="sq-body mt-1 text-xs" style={{ color: C.muted }}>
                Calibrated from your three responses — not a final grade, a learning-evidence signal
                for your instructor.
              </p>
            </div>
            {results.map((r) => (
              <div
                key={r.q.id}
                className="rounded-2xl border p-4"
                style={{ borderColor: C.border }}
              >
                <div className="flex items-center justify-between">
                  <p className="sq-body text-sm font-semibold" style={{ color: C.text }}>
                    {r.q.type}
                  </p>
                  <OutcomePill outcome={r.outcome} />
                </div>
                <p className="sq-body mt-2 text-xs" style={{ color: C.muted }}>
                  Evidence tag: {r.tag}
                </p>
              </div>
            ))}
            <PrimaryButton
              tone="primary"
              className="w-full"
              onClick={() => overall && onFinish(overall, results)}
            >
              Done
            </PrimaryButton>
          </div>
        )}
      </div>
    </div>
  )
}
