"use client"

import { useEffect, useRef } from "react"
import { Loader2, Lock, Send } from "lucide-react"
import { ChatBubble } from "@/components/ui/chat-bubble"
import { GuardrailStatus } from "./guardrail-status"
import { C } from "@/lib/design-tokens"
import type { Message } from "@/lib/types"

interface CoachPanelProps {
  messages: Message[]
  loading: boolean
  submitted: boolean
  chatInput: string
  onChatInputChange: (value: string) => void
  onSend: () => void
}

export function CoachPanel({
  messages,
  loading,
  submitted,
  chatInput,
  onChatInputChange,
  onSend,
}: CoachPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, loading])

  const canSend = submitted && !loading

  return (
    <section
      className="relative flex flex-col overflow-hidden rounded-3xl border bg-white shadow-sm"
      style={{ borderColor: C.border }}
    >
      <div
        className="flex items-center justify-between px-6 py-4"
        style={{
          borderBottom: `3px solid ${C.terracotta}`,
          background: `linear-gradient(90deg, ${C.peachWash}, #FFFFFF)`,
        }}
      >
        <h2 className="sq-display text-base font-semibold" style={{ color: C.text }}>
          Socratic AI Coach
        </h2>
        <GuardrailStatus />
      </div>

      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-white px-6 py-5">
        {messages.length === 0 && !loading && (
          <p className="sq-body text-sm" style={{ color: C.muted }}>
            Once you submit your attempt, the Coach will ask a guiding question grounded in it — not
            a solution.
          </p>
        )}
        {messages.map((m, i) => (
          <ChatBubble key={i} role={m.role} content={m.content} />
        ))}
        {loading && (
          <div className="sq-body flex items-center gap-2 text-sm" style={{ color: C.muted }}>
            <Loader2 size={14} className="animate-spin" />
            Thinking through a question...
          </div>
        )}
      </div>

      <div className="border-t bg-white px-4 py-4" style={{ borderColor: C.border }}>
        <div
          className="flex items-center gap-2 rounded-full border px-4 py-2"
          style={{ borderColor: C.border }}
        >
          <input
            value={chatInput}
            onChange={(e) => onChatInputChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) onSend()
            }}
            disabled={!submitted || loading}
            placeholder={submitted ? "Start your chat here..." : "Submit your attempt to unlock the Coach"}
            className="sq-body flex-1 bg-transparent text-sm outline-none disabled:opacity-60"
            style={{ color: C.text }}
          />
          <button
            onClick={onSend}
            disabled={!canSend || !chatInput.trim()}
            aria-label="Send message"
            className="sq-btn sq-primary flex h-8 w-8 items-center justify-center rounded-full disabled:opacity-40"
          >
            <Send size={14} color="#FFFFFF" />
          </button>
        </div>
      </div>

      {!submitted && (
        <div
          className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center"
          style={{ backgroundColor: "rgba(253,252,251,0.94)" }}
        >
          <div
            className="flex h-12 w-12 items-center justify-center rounded-full"
            style={{ backgroundColor: C.peachWash }}
          >
            <Lock size={20} color={C.terracotta} />
          </div>
          <p className="sq-display text-sm font-semibold" style={{ color: C.text }}>
            Coaching unlocks after your attempt
          </p>
          <p className="sq-body text-xs" style={{ color: C.muted }}>
            Under Guided mode, you diagnose first — the Coach responds to what you&apos;ve already
            tried.
          </p>
        </div>
      )}
    </section>
  )
}
