"use client"

import type { LucideIcon } from "lucide-react"
import { ChevronLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { Logo } from "@/components/ui/logo"
import { C } from "@/lib/design-tokens"

interface AppTopBarProps {
  name: string
  fallback: string
  icon: LucideIcon
  iconBg: string
  iconFg: string
}

/**
 * Shared chrome for the authenticated views (workspace + dashboard):
 * a back-to-landing control, the wordmark, and the current persona chip.
 */
export function AppTopBar({ name, fallback, icon: Icon, iconBg, iconFg }: AppTopBarProps) {
  const router = useRouter()
  return (
    <header
      className="flex items-center justify-between border-b px-6 py-4 md:px-10"
      style={{ borderColor: C.border, backgroundColor: "#FFFFFF" }}
    >
      <div className="flex items-center gap-3">
        <button
          onClick={() => router.push("/")}
          aria-label="Back to landing"
          className="sq-body flex items-center gap-1 text-sm font-semibold"
          style={{ color: C.muted }}
        >
          <ChevronLeft size={16} />
        </button>
        <Logo />
      </div>
      <div
        className="sq-body flex items-center gap-2 text-sm font-semibold"
        style={{ color: C.text }}
      >
        <div
          className="flex h-8 w-8 items-center justify-center rounded-full"
          style={{ backgroundColor: iconBg }}
        >
          <Icon size={16} style={{ color: iconFg }} />
        </div>
        {name || fallback}
      </div>
    </header>
  )
}
