"use client"

import { LayoutGrid } from "lucide-react"
import { usePathname, useRouter } from "next/navigation"
import { C } from "@/lib/design-tokens"
import { useSession } from "@/context/session-context"
import type { Role } from "@/lib/types"

interface SwitcherItem {
  label: string
  href: string
  ensure?: Role
}

const ITEMS: SwitcherItem[] = [
  { label: "Landing", href: "/" },
  { label: "Student Workspace", href: "/workspace", ensure: "student" },
  { label: "Instructor Dashboard", href: "/dashboard", ensure: "teacher" },
]

/**
 * Persistent utility chrome, deliberately dark. Jumps directly between the
 * three primary views, filling in demo identities so a destination is never
 * rendered without a persona.
 */
export function FloatingSwitcher() {
  const pathname = usePathname()
  const router = useRouter()
  const { ensureIdentity } = useSession()

  const jump = (item: SwitcherItem) => {
    if (item.ensure) ensureIdentity(item.ensure)
    router.push(item.href)
  }

  return (
    <div
      className="sq-body fixed right-4 top-4 z-50 flex items-center gap-1 rounded-full border p-1 shadow-lg"
      style={{
        backgroundColor: "rgba(45,41,38,0.92)",
        borderColor: "rgba(255,255,255,0.1)",
        backdropFilter: "blur(6px)",
      }}
    >
      <LayoutGrid size={14} color={C.peach} className="ml-2 mr-1" />
      {ITEMS.map((item) => {
        const active = pathname === item.href
        return (
          <button
            key={item.href}
            onClick={() => jump(item)}
            className="rounded-full px-3 py-1.5 text-xs font-semibold"
            style={{
              transition: "background-color 0.15s ease, color 0.15s ease",
              backgroundColor: active ? C.amber : "transparent",
              color: active ? "#FFFFFF" : "#E7DFD6",
            }}
          >
            {item.label}
          </button>
        )
      })}
    </div>
  )
}
