import { C } from "@/lib/design-tokens"
import type { ChatRole } from "@/lib/types"

interface ChatBubbleProps {
  role: ChatRole
  content: string
}

export function ChatBubble({ role, content }: ChatBubbleProps) {
  const isUser = role === "user"
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className="sq-body rounded-2xl px-4 py-2.5 text-sm leading-relaxed"
        style={{
          maxWidth: "85%",
          backgroundColor: isUser ? C.terracotta : C.aiWash,
          color: isUser ? "#FFFFFF" : C.text,
        }}
      >
        {content}
      </div>
    </div>
  )
}
