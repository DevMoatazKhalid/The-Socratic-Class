import { OUTCOME_STYLE } from "@/lib/verification-engine"
import type { Outcome } from "@/lib/types"

export function OutcomePill({ outcome }: { outcome: Outcome }) {
  const s = OUTCOME_STYLE[outcome] || OUTCOME_STYLE.IN_PROGRESS
  return (
    <span
      className="sq-body rounded-full px-3 py-1 text-xs font-semibold"
      style={{ backgroundColor: s.bg, color: s.fg }}
    >
      {s.label}
    </span>
  )
}
