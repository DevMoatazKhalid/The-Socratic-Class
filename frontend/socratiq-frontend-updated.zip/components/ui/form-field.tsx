import type { ChangeEventHandler, KeyboardEventHandler } from "react"
import { C } from "@/lib/design-tokens"

interface FormFieldProps {
  type?: string
  value: string
  onChange: ChangeEventHandler<HTMLInputElement>
  placeholder?: string
  onKeyDown?: KeyboardEventHandler<HTMLInputElement>
}

export function FormField({
  type = "text",
  value,
  onChange,
  placeholder,
  onKeyDown,
}: FormFieldProps) {
  return (
    <div className="mb-3 text-left">
      <input
        type={type}
        value={value}
        onChange={onChange}
        onKeyDown={onKeyDown}
        placeholder={placeholder}
        className="sq-body w-full rounded-full border px-5 py-3 text-sm outline-none transition-colors focus:ring-2"
        style={{ borderColor: C.border, color: C.text, backgroundColor: C.bgOff }}
      />
    </div>
  )
}
