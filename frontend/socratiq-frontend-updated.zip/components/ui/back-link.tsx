import { ChevronLeft } from "lucide-react"
import { C } from "@/lib/design-tokens"

interface BackLinkProps {
  onClick: () => void
  label?: string
}

export function BackLink({ onClick, label = "Go to previous" }: BackLinkProps) {
  return (
    <button
      onClick={onClick}
      className="sq-body sq-btn mx-auto mt-8 flex items-center gap-1 text-sm font-semibold"
      style={{ color: C.text, backgroundColor: "transparent" }}
    >
      <ChevronLeft size={16} />
      {label}
    </button>
  )
}
