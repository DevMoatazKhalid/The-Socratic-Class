import type { ButtonHTMLAttributes, ReactNode } from "react"
import { cn } from "@/lib/utils"

export type ButtonTone = "primary" | "amber" | "olive"

interface PrimaryButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode
  tone?: ButtonTone
}

const TONE_CLASS: Record<ButtonTone, string> = {
  primary: "sq-primary",
  amber: "sq-amber",
  olive: "sq-olive",
}

export function PrimaryButton({
  children,
  tone = "primary",
  className,
  type = "button",
  ...rest
}: PrimaryButtonProps) {
  return (
    <button
      type={type}
      className={cn(
        "sq-body sq-btn rounded-full px-6 py-3 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50",
        TONE_CLASS[tone],
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  )
}
