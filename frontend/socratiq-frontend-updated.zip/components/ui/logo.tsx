import { C } from "@/lib/design-tokens"

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="sq-display inline-flex items-center text-xl font-semibold tracking-tight" style={{ color: light ? "#FFFFFF" : C.text }}>
      <span
        aria-hidden
        className="mr-2 inline-block h-[7px] w-[7px] rounded-full"
        style={{ backgroundColor: light ? "#FFFFFF" : C.amberDeep }}
      />
      SocratiQ
    </span>
  )
}
