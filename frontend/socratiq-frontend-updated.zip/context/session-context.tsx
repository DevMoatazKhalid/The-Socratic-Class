"use client"

import { createContext, useCallback, useContext, useMemo, useState } from "react"
import type { Dispatch, ReactNode, SetStateAction } from "react"
import type { LiveState, Role } from "@/lib/types"

export const EMPTY_LIVE_STATE: LiveState = {
  attempt: "",
  revisions: [],
  messages: [],
  submitted: false,
  verificationOverall: null,
  verificationDetail: null,
}

interface SessionContextValue {
  studentName: string
  teacherName: string
  setStudentName: (name: string) => void
  setTeacherName: (name: string) => void
  liveState: LiveState
  setLiveState: Dispatch<SetStateAction<LiveState>>
  resetLiveState: () => void
  /** Guarantees a persona name exists before a view renders. */
  ensureIdentity: (role: Role) => void
}

const SessionContext = createContext<SessionContextValue | null>(null)

export function SessionProvider({ children }: { children: ReactNode }) {
  const [studentName, setStudentName] = useState("")
  const [teacherName, setTeacherName] = useState("")
  const [liveState, setLiveState] = useState<LiveState>(EMPTY_LIVE_STATE)

  const resetLiveState = useCallback(() => setLiveState(EMPTY_LIVE_STATE), [])

  const ensureIdentity = useCallback(
    (role: Role) => {
      if (role === "student") setStudentName((n) => n || "Demo Student")
      else setTeacherName((n) => n || "Demo Teacher")
    },
    [],
  )

  const value = useMemo<SessionContextValue>(
    () => ({
      studentName,
      teacherName,
      setStudentName,
      setTeacherName,
      liveState,
      setLiveState,
      resetLiveState,
      ensureIdentity,
    }),
    [studentName, teacherName, liveState, resetLiveState, ensureIdentity],
  )

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
}

export function useSession(): SessionContextValue {
  const ctx = useContext(SessionContext)
  if (!ctx) throw new Error("useSession must be used within a SessionProvider")
  return ctx
}
