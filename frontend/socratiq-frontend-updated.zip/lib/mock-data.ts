import { PenLine, SearchCode, HelpCircle, RotateCcw } from "lucide-react"
import type {
  Assignment,
  LoopStep,
  Misconception,
  RiskSignalKey,
  Student,
  VerificationQuestion,
} from "./types"

export const ASSIGNMENT: Assignment = {
  course: "Math_sec 2",
  title: "Implement Gradient Descent for Linear Regression",
  topic: "Linear Regression · Gradient Descent",
  description:
    "Write a function that fits a single-variable linear regression model using batch gradient descent. Given feature vector x, target vector y, an initial theta, a learning rate alpha, and a number of iterations, return the learned parameters. Your function should update theta on every iteration using the gradient of the mean-squared-error cost function.",
  policy: "GUIDED",
}

export const LOOP_STEPS: LoopStep[] = [
  { label: "Attempt", icon: PenLine },
  { label: "Diagnose", icon: SearchCode },
  { label: "Question", icon: HelpCircle },
  { label: "Revise", icon: RotateCcw },
]

export const RISK_SIGNAL_LABELS: Record<RiskSignalKey, string> = {
  unusually_large_attempt_jump: "Unusually Large Attempt Jump",
  solution_sophistication_inconsistent_with_prior_attempt:
    "Solution Sophistication Inconsistent With Prior Attempt",
  style_shift_between_attempts: "Style Shift Between Attempts",
}

export const STUDENTS: Student[] = [
  {
    id: 1,
    name: "Amina K.",
    email: "amina.k@student.edu",
    taskSubmission: 88,
    socraticUsage: 23,
    externalUsage: 3,
    mastery: "Strong",
    verification: "PASS",
    riskSignals: [],
    trace: {
      initialAttempt:
        "def gradient_descent(x, y, theta, alpha, iters):\n    for i in range(iters):\n        pass",
      interventions: [
        {
          role: "coach",
          content:
            "I notice the loop body doesn't change theta yet. What should happen inside each iteration?",
        },
        {
          role: "student",
          content:
            "I think I need to compute the error, then subtract alpha times the gradient from theta.",
        },
        {
          role: "coach",
          content:
            "Good instinct — what exactly is 'the gradient' here, in terms of x, y, and theta?",
        },
        { role: "student", content: "The average of (prediction - y) times x, I believe." },
      ],
      revisions: [
        { ts: "10:02", summary: "Added loop skeleton" },
        { ts: "10:11", summary: "Added gradient computation using dot product" },
        { ts: "10:19", summary: "Added theta update rule" },
      ],
      verificationDetail: [
        { q: "Explain", outcome: "PASS", tag: "EXPLANATION · STRONG" },
        { q: "Modify", outcome: "PASS", tag: "TRANSFER · MODERATE" },
        { q: "Transfer", outcome: "PARTIAL", tag: "TRANSFER · WEAK" },
      ],
    },
  },
  {
    id: 2,
    name: "Youssef T.",
    email: "youssef.t@student.edu",
    taskSubmission: 82,
    socraticUsage: 9,
    externalUsage: 21,
    mastery: "Moderate",
    verification: "PARTIAL",
    riskSignals: ["unusually_large_attempt_jump"],
    trace: {
      initialAttempt: "def gd(x,y,theta,alpha,n):\n    return theta",
      interventions: [
        {
          role: "coach",
          content:
            "Right now this returns theta unchanged. What's the first change you'd make to start updating it?",
        },
        { role: "student", content: "ok" },
      ],
      revisions: [
        { ts: "11:04", summary: "Attempt unchanged (14 chars)" },
        { ts: "11:22", summary: "Full 41-line implementation submitted in a single edit" },
      ],
      verificationDetail: [
        { q: "Explain", outcome: "PARTIAL", tag: "EXPLANATION · MODERATE" },
        { q: "Modify", outcome: "NEEDS_RETRY", tag: "TRANSFER · WEAK" },
        { q: "Transfer", outcome: "PARTIAL", tag: "TRANSFER · MODERATE" },
      ],
    },
  },
  {
    id: 3,
    name: "Nourhan S.",
    email: "nourhan.s@student.edu",
    taskSubmission: 94,
    socraticUsage: 40,
    externalUsage: 8,
    mastery: "Moderate",
    verification: "PASS",
    riskSignals: ["style_shift_between_attempts"],
    trace: {
      initialAttempt:
        "theta = 0\n# trying stuff\nfor i in range(10):\n  theta = theta - 0.1",
      interventions: [
        {
          role: "coach",
          content:
            "Theta changes each loop, but not based on the data at all yet. What should influence how much it changes?",
        },
        { role: "student", content: "The error between my prediction and the real y value." },
        {
          role: "coach",
          content:
            "Exactly the right direction. How would you turn 'the error' into a single number you can subtract from theta?",
        },
      ],
      revisions: [
        { ts: "09:14", summary: "No formal structure, informal scratch code" },
        { ts: "09:31", summary: "Reformatted with docstring, type-annotated helper functions" },
      ],
      verificationDetail: [
        { q: "Explain", outcome: "PASS", tag: "EXPLANATION · STRONG" },
        { q: "Modify", outcome: "PASS", tag: "TRANSFER · STRONG" },
        { q: "Transfer", outcome: "PASS", tag: "TRANSFER · MODERATE" },
      ],
    },
  },
  {
    id: 4,
    name: "Karim H.",
    email: "karim.h@student.edu",
    taskSubmission: 61,
    socraticUsage: 31,
    externalUsage: 2,
    mastery: "Weak",
    verification: "NEEDS_RETRY",
    riskSignals: [],
    trace: {
      initialAttempt:
        "def gradient_descent(x, y, theta, alpha, iters):\n    for i in range(iters):\n        theta = theta - alpha",
      interventions: [
        {
          role: "coach",
          content:
            "You're subtracting alpha directly from theta each time. What role is alpha meant to play alongside the gradient, rather than instead of it?",
        },
        {
          role: "student",
          content: "I'm not sure, isn't alpha the amount we change theta by?",
        },
        {
          role: "coach",
          content:
            "Close — alpha scales the change. What should it be multiplied by, based on the error in your predictions?",
        },
      ],
      revisions: [{ ts: "14:02", summary: "Initial attempt, unrevised since" }],
      verificationDetail: [
        { q: "Explain", outcome: "NEEDS_RETRY", tag: "EXPLANATION · WEAK" },
        { q: "Modify", outcome: "INSUFFICIENT_EVIDENCE", tag: "TRANSFER · —" },
        { q: "Transfer", outcome: "NEEDS_RETRY", tag: "TRANSFER · WEAK" },
      ],
    },
  },
  {
    id: 5,
    name: "Laila M.",
    email: "laila.m@student.edu",
    taskSubmission: 90,
    socraticUsage: 18,
    externalUsage: 12,
    mastery: "Moderate",
    verification: "PARTIAL",
    riskSignals: ["solution_sophistication_inconsistent_with_prior_attempt"],
    trace: {
      initialAttempt: "x = 1",
      interventions: [
        {
          role: "coach",
          content:
            "That's a starting point, but it doesn't touch theta, alpha, or iteration yet. What's the function signature you need first?",
        },
        {
          role: "student",
          content: "def gradient_descent(x, y, theta, alpha, iterations):",
        },
      ],
      revisions: [
        { ts: "08:40", summary: "Single line, no function defined (5 chars)" },
        { ts: "08:58", summary: "Complete function with 3 helper functions and full docstrings" },
      ],
      verificationDetail: [
        { q: "Explain", outcome: "PASS", tag: "EXPLANATION · MODERATE" },
        { q: "Modify", outcome: "PARTIAL", tag: "TRANSFER · MODERATE" },
        { q: "Transfer", outcome: "PARTIAL", tag: "TRANSFER · WEAK" },
      ],
    },
  },
]

export const MISCONCEPTIONS: Misconception[] = [
  { label: "Incorrect gradient sign in the update rule", count: 6 },
  { label: "Missing feature scaling before training", count: 4 },
  { label: "Treating alpha as a fixed offset, not a scale factor", count: 4 },
  { label: "Confusing the cost function with the prediction function", count: 2 },
]

export const VERIFICATION_QUESTIONS: VerificationQuestion[] = [
  {
    id: "explain",
    type: "Explain",
    prompt: "Explain how the learning rate (alpha) affects convergence.",
    keywords: ["too large", "too small", "diverge", "slow", "overshoot", "oscillate", "converge"],
  },
  {
    id: "modify",
    type: "Modify",
    prompt: "How would you modify this to handle feature scaling?",
    keywords: ["normalize", "standardize", "mean", "scale", "z-score", "min-max", "feature scaling"],
  },
  {
    id: "transfer",
    type: "Transfer",
    prompt: "How does batch gradient descent differ when applied to logistic regression?",
    keywords: ["sigmoid", "log loss", "cross-entropy", "probability", "classification", "logistic"],
  },
]
