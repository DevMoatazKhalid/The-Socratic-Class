/**
 * DESIGN TOKENS — Mint / Periwinkle / Teal / Sage / Plum,
 * on white & off-white canvases.
 *
 * These hex values are the single source of truth for the inline styles used
 * across SocratiQ. The interactive component classes (.sq-primary, .sq-amber,
 * .sq-olive, .sq-btn) mirror the same values in `app/globals.css`.
 */
export const C = {
  terracotta: "#776871", // primary brand accent (plum)
  terracottaDeep: "#5E5159", // hover state for primary
  amber: "#AFDEDC", // secondary interactive (teal)
  amberDeep: "#8FC7C4", // hover state for amber
  peach: "#C4D7F2", // tinted wash (periwinkle)
  peachWash: "#F0F7EE", // very subtle pill / badge fill
  peachRow: "rgba(196,215,242,0.25)", // live-row highlight
  sage: "#91A8A4", // neutral accent & badges
  sageWash: "rgba(145,168,164,0.22)", // pass-state fill
  amberWash: "rgba(175,222,220,0.16)", // warning fill
  oliveEarth: "#5E5159", // rich text & dark accents
  oliveEarthDeep: "#463C42", // hover state for olive
  oliveDark: "#332B34", // deep dark surface (footer / chrome)
  text: "#332B34", // primary text
  muted: "#7A7079", // subtitle / secondary text
  border: "#E3E9DE", // hairline border
  borderStrong: "rgba(119,104,113,0.12)",
  bg: "#FFFFFF",
  bgOff: "#F0F7EE",
  aiWash: "#F5FAF4", // AI chat bubble wash
} as const

export type DesignTokens = typeof C
export type TokenKey = keyof DesignTokens
