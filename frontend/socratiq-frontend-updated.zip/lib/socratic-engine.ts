/**
 * LOCAL SOCRATIC RESPONSE ENGINE
 *
 * No external API call. Three layers, checked in order:
 *   1) direct-answer rejection (regex)
 *   2) conceptual-intent matching (alpha / cost function / divergence /
 *      update rule) — answers the actual question, partially, while
 *      still ending on a guiding question (GUIDED policy)
 *   3) code diagnosis fallback, reacting to what's actually written
 */

interface ConceptualIntent {
  id: string
  pattern: RegExp
  responses: string[]
}

interface CodeAnalysis {
  hasLoop: boolean
  hasThetaUpdate: boolean
  hasGradientTerm: boolean
  length: number
}

const REJECT_PATTERNS: RegExp[] = [
  /give me the (answer|code|solution)/i,
  /write (it|the code|this) for me/i,
  /just tell me/i,
  /solve (it|this) for me/i,
  /what('?s| is) the (solution|answer)/i,
  /do it for me/i,
  /can you (just )?(write|solve|finish|complete) (it|this|the code)/i,
  /give me the formula/i,
  /show me the code/i,
]

const REJECTION_RESPONSES: string[] = [
  "I can't write the solution for you — that would skip the part where you actually learn it. Let's think: what is the mathematical rule for updating theta using the gradient of the cost function?",
  "That's the part you get to work out. Instead: what does the gradient of the mean-squared-error cost function tell you about which direction to move theta?",
  "I won't hand you the code, but I'll help you reason toward it. What should happen to theta when your prediction is higher than the actual y?",
]

const CONCEPTUAL_INTENTS: ConceptualIntent[] = [
  {
    id: "alpha",
    pattern: /\balpha\b|learning rate/i,
    responses: [
      "Alpha scales the size of each step — it doesn't decide the direction, the gradient does. Given that, what do you think happens to your updates if alpha is set much larger than it needs to be?",
      "Think of alpha as a multiplier on the gradient before you subtract it from theta. If your cost is bouncing up and down between iterations rather than settling, what does that suggest about alpha's size?",
    ],
  },
  {
    id: "cost",
    pattern: /cost function|mse|mean squared error|loss function/i,
    responses: [
      "The cost function measures how far your predictions are from the real y values, squared and averaged so errors in either direction count the same. If you plotted cost against a single theta value, what shape would you expect the curve to have, and why does that shape matter for finding a minimum?",
      "It's the quantity gradient descent is trying to minimize — squared error, averaged over all examples. What would it mean, geometrically, for the gradient of that function to be zero?",
    ],
  },
  {
    id: "diverge",
    pattern: /diverg|blow(ing)? up|explod|not (converging|going down)|cost (is )?increasing/i,
    responses: [
      "Divergence usually means each step is overshooting further than the last one did. Given that alpha controls step size, what's the first thing you'd try changing?",
      "If cost is increasing instead of decreasing, the update is moving theta in the wrong direction or too far in the right one. Which of those two would a smaller alpha fix?",
    ],
  },
  {
    id: "update_rule",
    pattern: /update (rule|theta)|how do i update|gradient update/i,
    responses: [
      "The update rule has a shape you've probably already sketched: theta changes by some amount related to alpha and the gradient. What do you think that 'some amount' should depend on — just alpha, or something about how wrong your current predictions are?",
      "Rather than the exact line of code, think about it conceptually first: should theta move toward or away from the direction that increases cost? Why?",
    ],
  },
]

const DIAGNOSTIC_RESPONSES: Record<string, string[]> = {
  empty: [
    "Let's start simple: what's the very first thing your function needs before any updates can happen — what does the signature need to accept?",
  ],
  noLoop: [
    "I don't see an iteration yet — gradient descent repeats the update many times. What structure would let you repeat a calculation a fixed number of times?",
    "Where's the part that repeats the update across iterations? What would you use to run the same steps multiple times in Python?",
  ],
  noUpdate: [
    "You have a loop, but I don't see theta actually changing inside it. What should happen to theta on each pass to move it toward lower cost?",
    "The loop runs, but does theta ever get reassigned inside it? What's missing there?",
  ],
  noGradient: [
    "Your update step is there, but where does the direction of that update come from? What do you need to compute from the prediction error before you can update theta?",
    "Before you subtract anything from theta, what quantity are you subtracting — and how is it derived from your predictions and the actual y values?",
  ],
  looksCorrect: [
    "This looks like a genuine gradient descent structure — a loop, a computed gradient, and a theta update. What happens to convergence if alpha is set too large?",
    "Solid structure. Now: how would you tell, just from watching the cost over iterations, whether alpha is too small rather than too large?",
    "Good — theta updates using a computed gradient inside a loop. What would change in your code if x had multiple features instead of one?",
  ],
}

/** Deterministic-but-varied pick, tolerant of negative seeds. */
export function pick<T>(arr: T[], seed: number): T {
  return arr[((seed % arr.length) + arr.length) % arr.length]
}

export function wantsDirectAnswer(message: string): boolean {
  return REJECT_PATTERNS.some((re) => re.test(message))
}

export function analyzeCode(code: string): CodeAnalysis {
  const hasLoop = /\bfor\b|\bwhile\b/.test(code)
  const hasThetaUpdate =
    /theta\s*(=\s*theta\s*-|-=)/.test(code) || /theta\s*=\s*theta\s*\+/.test(code)
  const hasGradientTerm = /grad|deriv|dot\(|\.dot\(|sum\(/i.test(code)
  const length = code.trim().length
  return { hasLoop, hasThetaUpdate, hasGradientTerm, length }
}

function matchConceptualIntent(message: string, turnCount: number): string | null {
  for (const intent of CONCEPTUAL_INTENTS) {
    if (intent.pattern.test(message)) {
      return pick(intent.responses, turnCount + intent.id.length)
    }
  }
  return null
}

export function diagnose(code: string, turnCount: number): string {
  const a = analyzeCode(code)
  if (a.length < 5) return pick(DIAGNOSTIC_RESPONSES.empty, turnCount)
  if (!a.hasLoop) return pick(DIAGNOSTIC_RESPONSES.noLoop, turnCount)
  if (!a.hasThetaUpdate) return pick(DIAGNOSTIC_RESPONSES.noUpdate, turnCount)
  if (!a.hasGradientTerm) return pick(DIAGNOSTIC_RESPONSES.noGradient, turnCount)
  return pick(DIAGNOSTIC_RESPONSES.looksCorrect, turnCount)
}

export function socraticRespond(userMessage: string, code: string, turnCount: number): string {
  if (wantsDirectAnswer(userMessage)) return pick(REJECTION_RESPONSES, turnCount)
  const conceptual = matchConceptualIntent(userMessage, turnCount)
  if (conceptual) return conceptual
  return diagnose(code, turnCount)
}

/** Simulated "thinking" latency so coaching feels considered, not instant. */
export function thinkingDelay(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 450))
}
