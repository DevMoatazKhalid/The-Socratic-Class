/**
 * LEARNING VERIFICATION ENGINE (Explain / Modify / Transfer)
 *
 * Turns a free-text answer into an evidence signal — never a final grade.
 */
import { C } from "./design-tokens"
import type { EvaluationResult, Outcome, OutcomeStyle, VerificationQuestion } from "./types"

export function evaluateAnswer(q: VerificationQuestion, text: string | undefined): EvaluationResult {
  const t = (text || "").trim().toLowerCase()
  if (t.length < 8) return { outcome: "INSUFFICIENT_EVIDENCE", tag: `${q.type.toUpperCase()} · —` }
  const hit = q.keywords.some((k) => t.includes(k))
  if (hit && t.length > 40) return { outcome: "PASS", tag: `${q.type.toUpperCase()} · STRONG` }
  if (hit || t.length > 40) return { outcome: "PARTIAL", tag: `${q.type.toUpperCase()} · MODERATE` }
  return { outcome: "NEEDS_RETRY", tag: `${q.type.toUpperCase()} · WEAK` }
}

/**
 * Pass = Sage Olive fill / Olive Earth text. Partial & Needs-retry share the
 * Soft Peach / Deep Terracotta treatment per the palette spec.
 */
export const OUTCOME_STYLE: Record<Outcome, OutcomeStyle> = {
  PASS: { bg: C.sageWash, fg: C.oliveEarth, label: "Pass" },
  PARTIAL: { bg: C.peachWash, fg: C.terracotta, label: "Partial" },
  NEEDS_RETRY: { bg: C.peachWash, fg: C.terracotta, label: "Needs retry" },
  INSUFFICIENT_EVIDENCE: { bg: "#F5F4F2", fg: C.muted, label: "Insufficient evidence" },
  IN_PROGRESS: { bg: "#F5F4F2", fg: C.muted, label: "In progress" },
}
