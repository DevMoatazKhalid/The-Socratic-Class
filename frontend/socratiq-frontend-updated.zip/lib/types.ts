import type { LucideIcon } from "lucide-react"

/** Which persona a session belongs to. */
export type Role = "student" | "teacher"

/** Outcome states shared by verification results and instructor rows. */
export type Outcome = "PASS" | "PARTIAL" | "NEEDS_RETRY" | "INSUFFICIENT_EVIDENCE" | "IN_PROGRESS"

/** Chat bubble authorship as rendered in the UI. */
export type ChatRole = "user" | "assistant"

/** Provenance intervention authorship as stored in traces. */
export type TraceRole = "coach" | "student"

/** Coarse mastery banding surfaced on the instructor dashboard. */
export type Mastery = "Strong" | "Moderate" | "Weak" | "—"

/** Stable identifiers for the observable risk signals. */
export type RiskSignalKey =
  | "unusually_large_attempt_jump"
  | "solution_sophistication_inconsistent_with_prior_attempt"
  | "style_shift_between_attempts"

export interface Message {
  role: ChatRole
  content: string
}

export interface TraceIntervention {
  role: TraceRole
  content: string
}

export interface Revision {
  ts: string
  summary: string
}

export interface VerificationDetailItem {
  q: string
  outcome: Outcome
  tag: string
}

export interface StudentTrace {
  initialAttempt: string
  interventions: TraceIntervention[]
  revisions: Revision[]
  verificationDetail: VerificationDetailItem[]
}

export interface Student {
  id: number | string
  name: string
  email: string
  taskSubmission: number
  socraticUsage: number
  externalUsage: number
  mastery: Mastery
  verification: Outcome
  riskSignals: RiskSignalKey[]
  trace: StudentTrace
}

export interface Assignment {
  course: string
  title: string
  topic: string
  description: string
  policy: string
}

export interface LoopStep {
  label: string
  icon: LucideIcon
}

export interface Misconception {
  label: string
  count: number
}

export type VerificationQuestionId = "explain" | "modify" | "transfer"

export interface VerificationQuestion {
  id: VerificationQuestionId
  type: string
  prompt: string
  keywords: string[]
}

export interface EvaluationResult {
  outcome: Outcome
  tag: string
}

export interface VerificationResult extends EvaluationResult {
  q: VerificationQuestion
}

/** Lifted state for the active, in-browser student session. */
export interface LiveState {
  attempt: string
  revisions: Revision[]
  messages: Message[]
  submitted: boolean
  verificationOverall: Outcome | null
  verificationDetail: VerificationResult[] | null
}

export interface OutcomeStyle {
  bg: string
  fg: string
  label: string
}
