import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Short local time label (e.g. "10:02") used to stamp revisions. */
export function nowLabel(): string {
  const d = new Date()
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
}
