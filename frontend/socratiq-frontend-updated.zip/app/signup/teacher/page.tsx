import { SignupForm } from "@/components/auth/signup-form"

export default function TeacherSignupPage() {
  return <SignupForm role="teacher" />
}
