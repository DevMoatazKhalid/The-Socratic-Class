import { SignupForm } from "@/components/auth/signup-form"

export default function StudentSignupPage() {
  return <SignupForm role="student" />
}
