import { StudentWorkspace } from "@/components/workspace/student-workspace"

export default function WorkspacePage() {
  return <StudentWorkspace />
}
