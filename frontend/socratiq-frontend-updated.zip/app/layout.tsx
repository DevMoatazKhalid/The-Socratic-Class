import type { Metadata, Viewport } from "next"
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { SessionProvider } from "@/context/session-context"
import { FloatingSwitcher } from "@/components/floating-switcher"
import "./globals.css"

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-space-grotesk",
  display: "swap",
})

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
  display: "swap",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "SocratiQ — The Critical Thinking Engine",
  description:
    "SocratiQ reimagines generative AI for academics as a Socratic critical-thinking engine: every attempt becomes a diagnosis, a question, and a revision — not an answer.",
  keywords: [
    "SocratiQ",
    "Socratic AI",
    "critical thinking",
    "education",
    "learning verification",
    "AI tutor",
  ],
  authors: [{ name: "SocratiQ" }],
  openGraph: {
    title: "SocratiQ — The Critical Thinking Engine",
    description:
      "A tool for teachers and students that turns AI from an answer machine into a Socratic coach.",
    type: "website",
  },
}

export const viewport: Viewport = {
  themeColor: "#776871",
  colorScheme: "light",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="light">
      <body className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable} sq-body antialiased`}>
        <SessionProvider>
          <FloatingSwitcher />
          {children}
        </SessionProvider>
        <Analytics />
      </body>
    </html>
  )
}
