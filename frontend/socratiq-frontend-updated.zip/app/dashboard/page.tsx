import { InstructorDashboard } from "@/components/dashboard/instructor-dashboard"

export default function DashboardPage() {
  return <InstructorDashboard />
}
